# Adventura – HUD TODO List

## Ziel

Das HUD soll die wichtigsten Survival-, Comfort-, Welt- und Feedback-Informationen klar, cozy und unaufdringlich anzeigen.

## P0 – HUD-Struktur

- Health, Hunger, Stamina/Energy, Breath und Comfort optisch einheitlich darstellen.
- gleiche Abstände, gleiche Skalierung, gleiche Icon-Logik.
- UI Scale berücksichtigen.
- Modi: Normal HUD, Minimal HUD, Debug HUD, Hidden HUD, Death HUD, Underwater HUD.

## P1 – Survival HUD

### Health
- volle, halbe und leere Herzen.
- Damage Feedback kurz animieren.
- Regeneration subtil anzeigen.

### Hunger
- volle, halbe und leere Hungerkeulen oder Beeren-Icons.
- Food Tooltip zeigt Auswirkung vor Nutzung.

### Stamina / Energy
- klar als Sprint-/Action-Ressource darstellen.
- Regen durch Comfort subtil markieren.
- niedrigen Wert kurz pulsen lassen.

### Breath
- volle, halbe und leere Luftblasen.

## P2 – Comfort HUD

- Comfort als cozy Meter mit Icon darstellen.
- Level: Low, Cozy, Warm, Restful, Homey.
- kurze Erklärung im Tooltip.
- bei neuem Comfort-Level einmalige Meldung.
- Quellen optional anzeigen: Campfire +5, Rug +3, Lantern +3.

## P3 – Weltinformationen

- Current Biome schöner darstellen.
- bei Biome-Wechsel kurze Meldung.
- Day/time mit Icon statt nur Text.
- Day Number anzeigen.
- Tageszeit: Morning, Noon, Evening, Night.
- Temperature nur anzeigen, wenn Temperature-System relevant ist.

## P4 – Interaction HUD

- Fortschritt: Anvisierte Blöcke und Entities zeigen jetzt einen UI-skalierten Interaction-Hint mit Zielname, Primäraktion, Tool-/Tier-Hinweis, Mining-Fortschritt, Storage-Range-Hint, Creature Feed/Observe und Item-Drop-Pickup; erreichbare Campfires nutzen das detaillierte Burn/Cook-HUD.
- Blockname beim Anvisieren anzeigen.
- benötigtes Tool anzeigen.
- Mining Progress am Block oder im HUD.
- Campfire: fuel, active/inactive, recipe, cook progress.
  - Fortschritt: Campfire-HUD zeigt beim Anvisieren Active/Inactive, Burn-Time, ausgewählten Fuel-Wert und laufenden Cook-Progress aus `CampfireStatus`.
- Cooking Pot/Forge: input needed, fuel needed, output ready.
  - Fortschritt: Cooking-Pot-HUD zeigt beim Anvisieren Pot-Ready, Rezeptbereitschaft und den Press-E-Cook-Hinweis; Forge bleibt offen. Testlauf bleibt bis lokalem JDK offen.
- Storage: Open-Hint und Range-Hint.

## P5 – Feedback Log

Kategorien:
- Pickup
- Craft Success
- Craft Fail
- Recipe Unlock
- Too Far Away
- Need Tool
- Inventory Full
- Comfort Level
- Biome Discovered
- Lore Found

Regeln:
- kurze Meldungen.
- gleiche Meldungen zusammenfassen.
- wichtige Meldungen länger sichtbar.

## P6 – Debug HUD

Engine Stats: FPS, Frame ms, Render ms, Update ms, Chunkgen ms, Meshing ms, Upload ms, Draw Calls, Triangles, VRAM, Loaded/Visible/Dirty Chunks.

Gameplay Stats: Position, Chunk Coordinate, Current Biome, Light Level, Looking at Block, Selected Item, Gamemode, raw survival values.

Network Stats: Ping, Server tick estimate, packets/sec optional, entity snapshot count, chunk packet count.
- Fortschritt: Packets/sec sind jetzt im Debug-HUD sichtbar (TX/s, RX/s auf Basis der bisherigen Laufzeitpakete).

## Akzeptanzkriterien

- HUD ist bei 1x, 1.5x und 2x UI Scale lesbar.
- Survival-Werte sind sofort verständlich.
- Comfort ist sichtbar, aber nicht aufdringlich.
- Debug HUD hilft beim Entwickeln.
- Feedback-Meldungen spammen nicht.
