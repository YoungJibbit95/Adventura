# Adventura – UI TODO List

## Ziel

Die UI soll cozy, klar, pixel-art-kompatibel und mausfreundlich werden. Sie soll Cooking, Forge, Journal, Recipe Unlocks und Storage sauber unterstützen.

## P0 – UI-Grundqualität

- warmer Pixel-Art-Stil.
- klare Rahmen und gute Lesbarkeit.
- UI Scale überall anwenden.
- ✅ Teilweise erledigt: Compact-Inventory (Slots, Header, Buttons, Hover, Durability-Bar) skaliert jetzt konsistent mit UI Scale.
- Hover/Pressed/Disabled States vereinheitlichen.
- zentrale Komponenten: Buttons, Panels, Slots, Tabs, Chips, Scrollbars, Tooltips, Progress Bars, Textfelder.

## P1 – Inventory UI

- ✅ Inventar-Hintergrund neu aufgebaut: Minecraft-artiges graues Panel statt falsch gestrecktem Inventory-Sprite, 3x9 Backpack oben und getrennte 9er-Hotbar unten.
- Fortschritt: Tool-Hover vergleicht jetzt Level, Haltbarkeit und Speed; Reparaturmaterialien kommen zentral aus `SlotView` und werden in Text- und Hover-Tooltips konsistent angezeigt.
- Drag/drop weiter testen.
- Shift-click quick move weiter testen.

## P2 – Crafting UI

- Recipe Book verbessern.
- Unlock-Historie anzeigen.
- locked recipes klar erklären.
- Rezept-Suche weiter verbessern.
- Filter speichern.
- fehlende Station prominent anzeigen.
- fehlende Zutaten gruppiert anzeigen.

Recipe Details:
- Name, Output, Zutaten, Station, Kategorie, Unlock Source, Crafting Time, Beschreibung.

## P3 – Cooking UI

### Campfire UI
- Fortschritt: Campfire-Cooking hat jetzt serverseitige Status-Snapshots (`CampfireStatus`) und zeigt im Crafting/HUD Input-, Fuel-, Output-, Burn- und Cook-Status inklusive Active/Inactive-Hinweis.
- Input Slot.
- Fuel Slot.
- Output Slot.
- Burn-Time-Anzeige.
- Cook-Time-Anzeige.
- Active/Inactive State.
- Fehlerfeedback: no fuel, no matching recipe, inventory full, campfire inactive.

### Cooking Pot UI
- Fortschritt: Cooking-Pot-Naehe priorisiert Pot-Rezepte im Crafting-Screen, nutzt ein eigenes Zutaten-/Output-/Cook-Time-Preview und nennt fehlendes Wasser, Bowl, Zutaten oder volles Inventar direkt im Rezeptstatus/Fehlerfeedback. HUD zeigt beim Anvisieren Pot-Ready und Anzahl bereiter Rezepte. Testlauf bleibt bis lokalem JDK offen.
- mehrere Rezeptoptionen.
- Wasser-/Container-Anforderung anzeigen.
- bessere Food Outputs.
- Fortschrittsbalken.

### Forge UI
- Ore Input.
- Fuel Input.
- Output.
- Heat/Burn Progress.
- Rezeptanforderungen.

## P4 – Storage UI

- ~~Shift-click zwischen Inventaren.~~ ✅ Erledigt (Storage-Slots transferieren per Shift-Click direkt zwischen Crate und Backpack).
- ~~Drag/drop.~~ ✅ Erledigt (Storage unterstützt zielgenaues Drag/drop zwischen Crate-Slots und Spieler-Slots; Online nutzt Zielslot-Transfers, lokale Crates können auch intern sortiert werden).
- spätere Storage-Typen: größere Chests, Market Crates, Loot Crates.

## P5 – Journal UI

Fortschritt:
- Ingame-Journal per J mit klickbaren Tabs für Notes, Biomes, Creatures, Recipes und Items; befüllt aus Clientdaten zu aktuellem Biome, Tag/Zeit, Comfort, Stationen, sichtbaren Kreaturen, Drops, Inventarfüllstand und Rezeptstatus.
- Fortschritt: Journal hat jetzt eine Structures-Seite für Storage, Campfire, Cooking Pot und Sleeping Mat inklusive Reichweiten-/Statuszeile und Alpha-Flow-Progress.

Seiten:
- Notes
- Biomes
- Structures
- Creatures
- Recipes
- Collectibles

Features:
- neue Einträge markieren.
- gefundene Lore lesen.
- Biome mit kurzem Text.
- Creature Infos.
- Recipe Unlock Source.
- Progress-Anzeige.

## P6 – Settings UI

Bestehend/erweitern:
- Render Distance, Preview Radius, FOV, Mouse Sensitivity, Water, AO, Shadows, Bloom/Glow, VSync, UI Scale.
- Fortschritt: Settings zeigt bei ausreichender Fensterhöhe eine kompakte Controls-Übersicht für Bewegung, Aktionen, Inventory-Mausgesten und HUD/Debug-Tasten.

Neu:
- Master Volume, Music Volume, Ambience Volume, SFX Volume, UI Volume.
- Particle Quality.
- Graphics Presets: Low, Medium, High.
- Keybind Screen.
- Mehr Optionen für grafikeinstellungen, worldgeneration settings

## P7 – Menüs

### Main Menu

### Pause Menu
- Resume, Settings, Save/Exit, Return to Main Menu.
- Fortschritt: Pause-Menü hat einen direkten Journal-Einstieg; Schließen aus diesem Pfad kehrt zurück ins Pause-Menü statt versehentlich ins Spiel.
- Debug options nur optional.

## P8 – UI Assets

Benötigt:
- inventory slot, selected slot frame, hover slot, disabled slot.
- button normal/hover/pressed.
- panel background.
- tab active/inactive.
- tooltip background.
- progress bar.
- icons: health, hunger, stamina, comfort, breath, armor optional, coin, recipe unlocked.

## Akzeptanzkriterien

- Inventory, Crafting, Storage und Settings nutzen konsistente Komponenten.
- UI Scale funktioniert überall.
- Locked Recipes sind verständlich.
- Cooking/Forge UI verhindert Verwirrung und Dupes.
