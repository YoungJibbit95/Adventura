# Adventura - Reproducible World Smoke Tests

These seeds and focus points are stable smoke-test anchors for rendering, gameplay and worldgen checks.

Use `--seed 1337` and teleport or fly to the listed focus point. The `Y` value is a useful camera or target reference, not a saved player spawn.

## Shared Checklist

- Spawn or teleport target is safe.
- No visible terrain seams around the focus chunk.
- Biome and surface materials match the scenario.
- Entities or natural details are visible where expected.
- FPS and debug overlay values look plausible.

## Seed Table

| Scenario | Seed | Focus X | Focus Y | Focus Z | Expected |
| --- | ---: | ---: | ---: | ---: | --- |
| Spawn baseline | 1337 | 8 | 120 | 8 | Starter campsite and nearby basic resources |
| River / lakeside | 1337 | -968 | 65 | -1272 | `voxel:lakeside` |
| Pine forest | 1337 | -920 | 95 | -1272 | `voxel:pine_forest` |
| Mushroom grove | 1337 | -40 | 94 | -936 | `voxel:mushroom_grove` |
| Cave pocket | 1337 | -56 | 68 | -504 | Generated cave air below terrain |
| Village / market | 1337 | 24 | 120 | 24 | `voxel:compact_village` |
| Frost peaks | 1337 | 760 | 102 | -952 | `voxel:frost_peaks` |
| Desert / dunes | 1337 | 1128 | 80 | -632 | `voxel:sun_dunes` |
| Old ruins | 1337 | -1144 | 79 | 1016 | `voxel:old_ruins` |

## Scenario Notes

- Spawn baseline: verify default hotbar, HUD, movement, starter campsite, nearby twig/pebble/fiber/berry/herb/mushroom resources and singleplayer startup.
- River / lakeside: verify water, shore materials, clay, reeds or berry resources and fog readability.
- Pine forest: verify pine trunks/leaves, forest ambience and entity visibility.
- Mushroom grove: verify mushroom resources, glow details and moss-snail ambience.
- Cave pocket: verify cave lighting/debug light values and collision at the surrounding stone shell.
- Village / market: verify roads, houses, market stall, loot markers and entity markers.
- Frost peaks: verify snow/ice materials and high-altitude visibility.
- Desert / dunes: verify sand terrain, dune silhouettes and sparse detail placement.
- Old ruins: verify old-ruins biome materials, glow crystals or structure candidates.
