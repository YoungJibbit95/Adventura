# Adventura – Physics TODO List

## Ziel

Die Physics soll stabil, vorhersehbar und zwischen Client und Server möglichst einheitlich sein. Survival-Bewegung muss weich sein, darf aber im Multiplayer nicht ausnutzbar sein.

## P0 – Physics-Architektur abschließen

- Input bleibt im Client.
- Simulation bleibt in `common/physics`.
- `Camera` wird View/Controller, nicht Physics-Engine.
- Freecam/Noclip-Controller-Rest weiter isolieren.
- Flying/Creative und Survival klar trennen.
- Client und Server nutzen gemeinsame Physics-Regeln.
- Air Strafen realistischer machen.
- Physics in allen Aspekten realistisch machen.

## P1 – Server Movement Validation

- ~~Kollision gegen Welt prüfen.~~ ✅ Server lehnt `PlayerMove` ab, wenn die Ziel-AABB mit kollidierbaren Blöcken überschneidet.
- ~~Ground-State plausibilisieren.~~ ✅ Server akzeptiert `onGround=true` nur mit Block-Support unter der Player-AABB.
- ~~Jump nur plausibel, wenn vorher grounded.~~ ✅ Server lehnt neue Aufwaertsbewegung in der Luft ab, erlaubt aber Grounded-Jump, laufenden Aufstieg und Wasser-Assist.
- ~~Water-State plausibilisieren.~~ ✅ `PlayerMove` uebertraegt Wasserflags; der Server lehnt uebertriebene Client-Wasserclaims ab und berechnet Movement-Assist autoritativ ueber Feet/Body/Head an der Player-AABB.
- Beschleunigung grob prüfen.
- Speed abhängig von Mode prüfen.
- Fortschritt: Server-Delta-Validation nutzt fuer Survival nicht mehr die Fly-Sprint-Obergrenze, sondern die Sprint-Speed-Huelle plus vertikale Wasser/Fall-Limits.
- ~~Fall-Damage/Impact serverseitig absichern.~~ ✅ Server berechnet Fallhöhe aus akzeptierten Moves, wertet Landung nur mit echtem Ground-Support und schickt nach Schaden einen autoritativen Stats-Snapshot.
- Movement mit Sequenznummern vorbereiten.
- Server sendet autoritativen State.
- Client kann später weich korrigieren.

## P2 – Collision Robustness

- Boden, Wand, Ecke, Head-Bump, Chunk-Grenzen testen.
- dünne Blocks/Fences optional.
- unbekannte Chunks dürfen nicht wie Luft behandelt werden.
- Bewegung sanft blockieren oder pausieren.
- Feedback optional: „Loading terrain...“.

## P3 – Wasserphysik

Flags:
- feetInWater.
- bodyInWater.
- headUnderwater.
- swimming.
- breath.
- waterDrag.

Gameplay:
- Wasser bremst horizontal.
- Space erlaubt Auftauchen.
- Breath sinkt nur bei headUnderwater.
- Splash Feedback beim Eintritt/Austritt.
- Strömung später optional.

Tests:
- Breath sinkt nur unter Wasser.
- Auftauchen regeneriert Breath.
- Wasser reduziert Fallgeschwindigkeit.
- Wasser verhindert/vermindert Fall Damage. ✅ Server-Tests decken harte Landung und Wasser-Dämpfung ab.

## P4 – Placement und Interaction Physics

- Platzieren in eigene Player-AABB verhindern.
- serverseitig gleiche Regel.
- Platzierung gegen andere Spieler/Entities später optional.
- klare Feedback-Meldung bei invalid placement.
- Range prüfen für Block-Abbau, Platzierung, Campfire, Crate, Cooking Pot, Forge, Entity Interactions und Sleep.
- Fortschritt: Server-Connection-Tests decken Far-Rejects für Block-Abbau, Platzierung, Campfire/Cook, Storage Open/Transfer, Entity Interact und Sleep ab.

## P5 – Entity Physics

- ~~einfache Collision optional.~~ ✅ Item-Drops haben jetzt eine kleine serverseitige Gravity/Bounce/Drag-Simulation und Pickup-Delay.
- Entities sollten nicht in Blöcken spawnen.
- Flee/Follow respektiert grob Terrain.
- Entities können nicht endlos durch Wände laufen.
- Despawn/Park außerhalb relevanter Chunks.
- Future: simple path steering, avoid water for some animals, prefer grass for grazers, fireflies ignore ground collision.
- Fortschritt: Dropped Items laufen über das bestehende Entity-Snapshot-System, werden nach kurzer Verzögerung eingesammelt und sind damit die erste wiederverwendbare Drop-Entity-Schicht.
- Fortschritt: Dropped-Item-Pickup nutzt jetzt einen atomaren Claim im Entity-Tracker, damit parallele Online-Pickups nicht denselben Drop doppelt vergeben; Testlauf bleibt bis lokalem JDK offen.

## P6 – Fall Damage und Movement Polish

- ~~definieren, ab welcher Höhe Schaden entsteht.~~ ✅ Server-Schaden beginnt nach 4 Blocks Fallhöhe.
- ~~Wasser reduziert Schaden.~~ ✅ Wasserberührung während Fall/Landung reduziert den berechneten Impact-Schaden stark.
- Creative/Spectator ausnehmen.
- ~~Server validiert Landung und Impact.~~ ✅ Impact basiert auf serverseitigem Ground-Support statt Client-Stats oder `onGround`-Trust.
- Movement Feel: sprint acceleration, grounded friction, air control, swim drag, jump buffer optional, coyote time optional.

## Tests

Unit:
- grounded jump, wall collision, sliding, head bump, fall impact, water drag, unknown chunk blocks movement, placement against player AABB.

Integration:
- server rejects impossible movement.
- server rejects survival speed bursts after an accepted move. ✅
- server rejects movement into collidable blocks. ✅
- server rejects forged grounded movement without support. ✅
- server rejects overstated water state and forged water-assisted upward movement. ✅
- server applies fall damage on real landing and cushions water impact. ✅
- ~~server rejects far interaction.~~ ✅ Abgedeckt durch Server-Connection-Tests für Block-, Station-, Storage-, Entity- und Sleep-Requests.
- ~~server rejects placement inside player.~~ ✅ Abgedeckt durch Server-Connection-Test für Block-Placement in Player-AABB.
- multiplayer movement snapshots stay plausible.

## Akzeptanzkriterien

- Spieler fällt nicht durch ungeladene Chunks.
- Movement fühlt sich weich an.
- Server akzeptiert keine extremen Teleports.
- Wasser ist klar spürbar.
- Block placement kann Player nicht einklemmen.
